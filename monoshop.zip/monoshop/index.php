<?php
    include('config/commande.php');
    // require 'config/commande.php';

    $Produits = afficher();

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.bundle.min.js" defer></script>
    <title>Document</title>
</head>
<body>
    
    <nav class="navbar navbar-expand-lg navbar-light bg-light px-3 py-3">
        <div class="ps-5 ">

            <h1 class="h2 ">Shop</h1>
        
        </div>
        <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbar-content">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbar-content"> 
            <ul class="navbar-nav nav-pills ms-auto">
                <li class="nav-item"><a class="nav-link active" href="#">Acceuil</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Articles</a></li>
                <li class="nav-item"><a class="nav-link" href="#">A propos</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Contact</a></li>
            </ul>
        </div>
        
    </nav>
   

    <header class="bg-dark py-5">

        <div class="container px-4 px-lg-5 my-5">
            <div class="text-center text-white">
                <h1 class="display-4 fw-bolder ">AhiLine</h1>
                <p class="lead fw-normal text-white-50 mb-0">Plus besoin de te Déplacer pour effectuer tes achats d'Outfit de bonne qualité et en toute sécurité.</p>
            </div>
        </div>
        
    </header>
    <section class="py-5">
       <div class="album py-5 bg-light">
        <div class="container">
            <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
                
            <?php foreach( $Produits as $produit):   ?> 

                    <div class="col mb-5"> 
                        <div class="card h-100">
                            <!-- Product image-->
                            <img src="" alt="" class="card-img-top">
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h4 class="fw-bolder">
                                        
                                    </h4>
                                    <!-- Product description-->
                                    <p class="card-text">

                                    </p>
                                    <div class="card-footer d-flex justify-content-between align-items-center  bg-transparent">
                                        <button type="submit" class="btn btn-outline-success">
                                            Acheter
                                        </button>
                                        <!-- Product price-->
                                        <small class="">
                                            
                                        </small>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </di>

                <?php endforeach; ?> 
    
            </div>
        </div>
       </div>
    </section>
    
</body>
</html>