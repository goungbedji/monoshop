<?php

function ajouter($picture, $nom, $prix, $libelle)
{
    require("connexion.php");

    $req = $access->prepare("INSERT INTO produit (picture, nom, prix, libelle) VALUES(:picture, :nom, :prix, :libelle)");
    
    $req->execute(array(
        ':picture' => $picture,
        ':nom' => $nom,
        ':prix' => $prix,
        ':libelle' => $libelle
    ));

    $req->closeCursor();
}

function afficher(){
    require("connexion.php");

    $req = $access->prepare("SELECT * FROM produit ORDER BY id DESC");

    $req->execute();

    $data = $req->fetchAll(PDO::FETCH_ASSOC);

    return $data;
}

function supprimer($id){
    require("connexion.php");

    $req = $access->prepare("DELETE FROM produit WHERE id=:id");

    $req->execute(array(':id' => $id));
}
?>
